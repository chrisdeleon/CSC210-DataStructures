package com.mycompany.game;
import java.util.Scanner;

/*
 * Chris de Leon
 * CSC210 Data Structures
 * 1/27/2023
 */

public class Game {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        
        /* Code below uses constructors from the Player class to create the two player profiles. 
           It also gathers the players' weapon information. */
        System.out.println("Enter player one name: ");
        Player playerOne = new Player(input.nextLine());
        System.out.println("Hello, " + playerOne.getName() + "! Enter your weapon: ");
        String playerOneWeapon = input.nextLine();
        System.out.println("Enter your weapon's action: ");
        String playerOneAction = input.nextLine();
        Weapon weaponOne = new Weapon(playerOneWeapon, playerOneAction);
        
        
        System.out.println("Enter player two name: ");
        Player playerTwo = new Player(input.nextLine());
        System.out.println("Hello, " + playerTwo.getName() + "! Enter your weapon: ");
        String playerTwoWeapon = input.nextLine();
        System.out.println("Enter your weapon's action: ");
        String playerTwoAction = input.nextLine();
        Weapon weaponTwo = new Weapon(playerTwoWeapon, playerTwoAction);
        
        
        
        
        
        // the counter has to be outside of the do-while loop or else it'll reset to 0 after every loop
        int counter = 0; 
        
        // this loop runs until a player's health is or drops below 0
        do {
            
            // selects a random number between 1 and 25, this number is used for hit points
            int randomNumber = (int) Math.floor((Math.random() * 26) + 1);
            
            // this counter alternates the players' turn and provides gameplay text
            if (counter % 2 == 0){
                System.out.println(playerOne.getName() + "'s weapon, " + weaponOne.strike(randomNumber));
                System.out.println(playerTwo.Attack(randomNumber));
            } else {
                System.out.println(playerTwo.getName() + "'s weapon, " + weaponTwo.strike(randomNumber));
                System.out.println(playerOne.Attack(randomNumber));
            }
            
            // remove code below to run the game automatically
            System.out.println("\nHit ENTER to continue"); 
            // remove code below to run game automatically
            input.nextLine(); 
            counter++;
        } while (playerOne.getHealth() >= 0 && playerTwo.getHealth() >= 0);
        
        // this if statement reads the player that has less than 0 health and determines the winner
        if(playerTwo.getHealth() >= 0){
            System.out.println(playerOne.getName() + " has died! " + playerTwo.getName() + " wins!");
            System.out.println(playerTwo.getName() + "'s remaining health: " + playerTwo.getHealth());
        } else {
            System.out.println(playerTwo.getName() + " has died! " + playerOne.getName() + " wins!");
            System.out.println(playerOne.getName() + "'s remaining health: " + playerOne.getHealth());
        }
    }
}
